# datasets-preprocessing-for-object-detection
this repository includes some python parser scripts for converting other public datasets into voc data  format
# note
- I don't mean to provide the usage for these scripts, it's very simple to modified these files
- most files in this repository are very similar, you can run for your own purpose
# environment
- python 3.5