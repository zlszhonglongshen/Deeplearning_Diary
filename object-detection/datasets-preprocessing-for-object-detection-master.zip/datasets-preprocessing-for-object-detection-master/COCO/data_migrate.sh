#val+train
python3 voc_data_migrate.py ./COCO/Annotations /media/data/COCO/val2014 /media/data/COCO/train2014 ./COCO/JPEGImages
