#train
python3 COCO_xml_parser.py  /media/data/COCO/instance_train_annotation_2 ./COCO/Annotations
#val
python3 COCO_xml_parser.py  /media/data/COCO/instance_val_annotation ./COCO/Annotations