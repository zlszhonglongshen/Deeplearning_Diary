# Dataset_to_VOC_converter
this is the extend files, if you want to run the whole problem, pleasure refer to the repository:https://github.com/CasiaFan/Dataset_to_VOC_converter

```
git clone https://github.com/CasiaFan/Dataset_to_VOC_converter.git
```

- then you can run these python scripts in this directory

 **extract cars and person,and save to Annotations directory**
```
sh parse.sh
```

 **copy image to JPEGImages directory**
```
sh data_migrate.sh
```

# environment
- python 3.5


# reference 
[markdown语法连接、代码块、段落](https://www.jianshu.com/p/9ab34d075bba)