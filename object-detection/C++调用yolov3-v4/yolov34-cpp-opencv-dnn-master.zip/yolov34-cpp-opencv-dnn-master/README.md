# 4种YOLO目标检测的C++实现
本程序包含了经典的YOLOv3，YOLOv4，Yolo-Fastest和YOLObile这4种YOLO目标检测的实现，
这4种yolo的.cfg和.weights文件，从百度云盘里下载

链接：https://pan.baidu.com/s/1xOZ-MM0G-NgmlYyrW0dGCA 
提取码：8kya 

下载完成后把下载得到的4个文件夹拷贝到和main_yolo.cpp同一目录下，
只要安装了opencv4.4.0，就可以在windows和linux系统编译和运行main_yolo.cpp
